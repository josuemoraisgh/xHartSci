#ifndef __XCOS_TOOLBOX_SKELETON_C_GW_H__
#define __XCOS_TOOLBOX_SKELETON_C_GW_H__

#include "c_gateway_prototype.h"

STACK_GATEWAY_PROTOTYPE(sci_tbx_sum);

#endif /* __XCOS_TOOLBOX_SKELETON_C_GW_H__ */
