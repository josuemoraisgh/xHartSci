/* This file is released under the 3-clause BSD license. See COPYING-BSD. */

double business_sum(double in, double in2)
{
    return in + in2;
}

